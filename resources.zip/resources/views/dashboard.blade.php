@extends('layout.main')
@section('title', 'Dashboard')

@section('styles')
<style>
    .fontBolde {
        font-weight: bold;
    }
</style>
@endsection

@section('contentHeader')
<div class="panel-header bg-primary-gradientM">
    <div class="page-inner py-5">
        {{--<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
            <div>
                <h2 class="text-white pb-2 fw-bold">Tableau de bord</h2>
                <!-- <h5 class="text-white op-7 mb-2">Gestion du ...</h5> -->
            </div>
            <!-- <div class="ml-md-auto py-2 py-md-0">
                <a href="#" class="btn btn-white btn-border btn-round mr-2">Manage</a>
                <a href="#" class="btn btn-secondary btn-round">Add Customer</a>
            </div> -->
        </div> --}}

        @if(Auth::user()->role->name == "Super Admin" || Auth::user()->role->name == "DG")
            @include('pages.dashboard.admin')
        @endif

        @if(Auth::user()->role->name == "Admin")
            @include('pages.dashboard.superviseur')
        @endif

        @if(Auth::user()->role->name == "AgentTerrain")
            @include('pages.dashboard.agent')
        @endif
    </div>
</div>
<div class="row justify-content-centerM">
    {{-- <div class="col-sm-8 text-center">
        <div class="card">
            <div class="card-body">
                <img src="{{asset('assets/img/logoSogema.png')}}" alt="Logo sogema" style="height: 130px" />
            </div>
        </div>
    </div> --}}    
</div>
@endsection