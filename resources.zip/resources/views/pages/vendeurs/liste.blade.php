@extends('layout.main')
@section('title', 'Dashboard')
@section('styles')
<style>
    
</style>
@endsection
@section('content')
<div class="row pl-4 pt-4">
    <div class="col-sm-6 col-lg-2">
        <div class="card p-3" style="max-height: 80px;">
            <div class="d-flex align-items-center">
                <span class="stamp stamp-md bg-secondary mr-3">
                    {{-- <i class="fa fa-dollar-sign"></i> --}}
                </span>
                <div class="text-center">
                    {{-- <h5 class="mb-1"><b><a href="#">132 <small>Sales</small></a></b></h5> --}}
                    <small class="text-muted">Magasin <br /> <strong>{{$placeNumber['magasin']}}</strong></small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-2">
        <div class="card p-3" style="max-height: 80px;">
            <div class="d-flex align-items-center">
                <span class="stamp stamp-md bg-secondary mr-3">
                    {{-- <i class="fa fa-dollar-sign"></i> --}}
                </span>
                <div class="text-center">
                    {{-- <h5 class="mb-1"><b><a href="#">132 <small>Sales</small></a></b></h5> --}}
                    <small class="text-muted">Etalage <br /> <strong>{{$placeNumber['etalage']}}</strong></small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-2">
        <div class="card p-3" style="max-height: 80px;">
            <div class="d-flex align-items-center">
                <span class="stamp stamp-md bg-secondary mr-3">
                    {{-- <i class="fa fa-dollar-sign"></i> --}}
                </span>
                <div class="text-center">
                    {{-- <h5 class="mb-1"><b><a href="#">132 <small>Sales</small></a></b></h5> --}}
                    <small class="text-muted">Kiosque <br /> <strong>{{$placeNumber['kiosque']}}</strong></small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-2">
        <div class="card p-3" style="max-height: 80px;">
            <div class="d-flex align-items-center">
                <span class="stamp stamp-md bg-secondary mr-3">
                    {{-- <i class="fa fa-dollar-sign"></i> --}}
                </span>
                <div class="text-center">
                    {{-- <h5 class="mb-1"><b><a href="#">132 <small>Sales</small></a></b></h5> --}}
                    <small class="text-muted">Entrepôt <br /> <strong>{{$placeNumber['entrepot']}}</strong></small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-2">
        <div class="card p-3" style="max-height: 80px;">
            <div class="d-flex align-items-center">
                <span class="stamp stamp-md bg-secondary mr-3">
                    {{-- <i class="fa fa-dollar-sign"></i> --}}
                </span>
                <div class="text-center">
                    {{-- <h5 class="mb-1"><b><a href="#">132 <small>Sales</small></a></b></h5> --}}
                    <small class="text-muted" style="font-weight: bold;">Chambre froide <br /> <strong style="font-weight: bold;">{{$placeNumber['chambreFroide']}}</strong></small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row pl-4 pr-4">
    {{-- <div class="col-sm-12">
        {{$placeNumber['magasin']}}
    </div> --}}
    <div class="col-sm-12 col-md-12 col-lg-12">
        <!-- <div class="row bg-successM justify-content-center myLoaderImgM">
            <div class="col-sm-4 bg-dangerM justify-content-center text-center">
                <img src="{{asset('assets/img/loading.gif')}}" alt="Chargement en cours..." id="myLoaderImg" style="height: 100px;" />
            </div>
        </div> -->
        <div class="card">
            <h4 class="card-title pl-4 pt-3">Liste vendeursM <span class="fw-bold bg_background colorText pl-3 pr-3 pt-1 pb-1" style="border-radius: 6px;">{{$vendeurCounts}}</span></h4>
            <div class="card-body">
                <div class="dt-responsiveM table-responsive">
                    <table id="simpletable" class="table table-striped table-bordered nowrap">
                        <thead>
                            <tr>
                                <th>{{ __('N°')}}</th>
                                <th>{{ __('Noms')}}</th>
                                {{-- <th>{{ __('Postnom')}}</th>
                                <th>{{ __('Prenom')}}</th> --}}
                                <th class="text-center">{{ __('Telephone') }}</th>                                
                                <th class="text-center">Date</th>
                                <th class="text-center">{{ __('Etat Doc')}}</th>
                                <th class="text-center">{{ __('Action')}}</th>
                            </tr>
                        </thead>
                        <tbody id="myTab">                            
                            <tr class="justify-content-center myLoaderImg">
                                <td colspan="7" class="justify-content-center text-center">
                                    <!-- <div class="col-sm-12 bg-dangerM justify-content-center text-center"> -->
                                        <img src="{{asset('assets/img/loading.gif')}}" alt="Chargement en cours..." id="myLoaderImg" style="height: 100px;" />
                                    <!-- </div> -->
                                </td>
                            </tr>                    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<script src="{{asset('assets/js/axios.min.js')}}"></script>
<script>
    getDataVendeurs();
    function getDataVendeurs(){
        // document.getElementById('myLoaderImg').style.display = "block";
        axios.get("{{route('vend.index')}}",{
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
        })
        .then(function (response) {
            var reponse = response.data;
            if(reponse != "") {
                document.getElementById('myLoaderImg').style.display = "none";
                //getDataElevesCount();
            }
            document.getElementById('myTab').innerHTML = reponse;
            console.log(reponse);
        })
        .catch(function (error) {
            // handle error
            console.log(error);
            alert(error);
        })
    }
</script>
@endsection