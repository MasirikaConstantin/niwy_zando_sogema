<?php 

return array(

    'failed' => "Ces informations d'identification ne correspondent.",
    'password' => 'Le mot de passe fourni est incorrect.',
    // 'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
    'throttle' => 'Trop de tentatives de connexion. Veuillez réessayer dans :secondes secondes.'

);